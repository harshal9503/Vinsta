// File: screens/Onboarding3.tsx

import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
} from 'react-native';
import { COLORS } from '../theme/colors';
import font from '../assets/fonts';

const { width, height } = Dimensions.get('window');

const Onboarding3 = ({ navigation }: any) => {
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: COLORS.secondary }}
      contentContainerStyle={styles.scrollContainer}
    >
      {/* Skip Button */}
      <TouchableOpacity
        onPress={() => navigation.navigate('SignIn')}
        style={styles.skipButton}
        activeOpacity={0.8}
      >
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Main Image */}
      <View style={styles.imageContainer}>
        <Image
          source={require('../assets/Onboarding3.png')}
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      {/* Text Content */}
      <View style={styles.textContainer}>
        <Text style={styles.title}>Gps Tracking</Text>
        <Text style={styles.description}>
          Track your order in real time with Vinsta – from the kitchen to your
          doorstep, know exactly where your food is, every step of the way.
        </Text>
      </View>

      {/* Pagination Dots */}
      <View style={styles.pagination}>
        <View style={styles.dot} />
        <View style={styles.dot} />
        <View style={[styles.dot, styles.activeDot]} />
      </View>

      {/* Full-width Login Button */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('SignIn')}
        activeOpacity={0.8}
      >
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: height * 0.07,
  },
  skipButton: {
    position: 'absolute',
    top: height * 0.06,
    right: width * 0.08,
    zIndex: 1,
  },
  skipText: {
    fontSize: width * 0.045,
    fontWeight: '600',
    color: COLORS.primary,
    fontFamily : 'Figtree-SemiBold'
  },
  imageContainer: {
    width: width * 0.9,
    height: height * 0.45,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: height * 0.1,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  textContainer: {
    paddingHorizontal: width * 0.08,
    alignItems: 'center',
    marginTop: height * 0.02,
  },
  title: {
    fontSize: width * 0.065,
    fontWeight: '700',
    color: COLORS.primary,
    textAlign: 'center',
    marginBottom: 10,
    fontFamily : 'Figtree-Bold'
  },
  description: {
    fontSize: width * 0.04,
    color: COLORS.text,
    textAlign: 'center',
    lineHeight: 22,
    fontFamily : 'Figtree-Medium',
    fontWeight : '500'
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: height * 0.03,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#D3D3D3',
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: COLORS.primary,
  },
  button: {
    backgroundColor: COLORS.primary,
    width: width * 0.85,
    paddingVertical: height * 0.018,
    borderRadius: 14,
    alignSelf: 'center',
    marginTop: height * 0.05,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  buttonText: {
    color: COLORS.secondary,
    fontSize: width * 0.05,
    fontWeight: '700',
    textAlign: 'center',
    fontFamily : 'Figtree-Bold'
  },
});

export default Onboarding3;
