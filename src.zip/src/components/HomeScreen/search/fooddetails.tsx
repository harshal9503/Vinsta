import { View, Text } from 'react-native'
import React from 'react'

const fooddetails = () => {
  return (
    <View>
      <Text>fooddetails</Text>
    </View>
  )
}

export default fooddetails