import { View, Text } from 'react-native'
import React from 'react'

const help = () => {
  return (
    <View>
      <Text>help</Text>
    </View>
  )
}

export default help