// Placeholder for utility functions
// Add more utility files as needed
